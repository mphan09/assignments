$( document ).ready(
	function() {
    //fade in and out
  	$("body").hide();
		$("body").show();
		$("#section-one").fadeOut();
		$("#section-one").fadeIn();
		$("#section-one").fadeOut(1000);
		$("#section-one").fadeIn(4000);
    //slide up and down
		$("#section-one").slideUp(1000);
		$("#section-one").slideDown(4000);
		$(".my-element").animate( {
			opacity: 0.25,
			width: "70%"
		} , 2000 );
    // clicking elements
		$("ul li a").click(
  		function(){
    		alert('imclicked!');
  		}
  		);
    //animation
  	$("#section-three").show( 
  		function(){
  	$("#section-three").animate( {
  				width: "80%"
  			}, 4000 );
		  });
    //hiding elements
		$("p").click(function(){
    $(this).hide();
   		});
		//link to twitter and alert pop-up
    $("ul li a").click( 
  		function(){
    		alert('You are now going to tweet!');
  		});
    //hide and show elements
		  $("#hide").click(function(){
      $("h4").hide();
   		 });
   		$("#show").click(function(){
      $("h4").show();
    	});
   	//animation
   	$("button").click(function(){
        var div = $("div");
        div.animate({height: '300px', opacity: '0.4'}, "slow");
        div.animate({width: '300px', opacity: '0.8'}, "slow");
        div.animate({height: '100px', opacity: '0.4'}, "slow");
        div.animate({width: '100px', opacity: '0.8'}, "slow");
    	});
   	//adding text elements
    	$("#btn2").click(function(){
        $("ol").append("<li>bananas</li>");
    	});
    //add class to elements
    	$("button").click(function(){
        $("h3").addClass("pink");
    	});
    //hover
		$("#p1").mouseenter(function(){
        alert("SURPRISE");
    	});
	}
);