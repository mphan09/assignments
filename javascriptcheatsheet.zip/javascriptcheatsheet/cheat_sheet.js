//alert("Hello");

//var playerName = "Melissa";
//var fullName = " Hi "  + playerName;

//console.log(playerName + fullName);

//var stringToShout=prompt('Name');
//var shout = stringToShout.toUpperCase();
//shout  =+ "!!!";

//if(true){
//    console.log("This is true");
//    }

//var message = "Hello";
//alert(message);

//message = "Welcome to JavaScript";
//alert(message);

//document.write("Welcome");
//alert("Thanks for visiting");

// var visitorName = prompt('What is your name?');
// alert(visitorName);

// console.log(visitorName);

// var myApartment = {
//        isGross: true,
//        address: "10 main street",
//        floor: 4,
// };

// console.log(myApartment.address);

//var iAmMel = {  
//    firstname: "Melissa",
//    lastname: "Phan",
//    interests: ["JS", "Dance"]
//};

//console.log(iAmMel.interests[0]);

//var x = 12;
//if (x<10) {
//   alert("Your number is less than 10");
//} else {
//    alert(x + " is greater than 10");
//}

//* an array //
animals = ["Tigers", "Pandas"]; 
    for(var i = 0; i< animals.length; i++)
    {   console.log(animals[i]); 
    }

>>"Tigers" "Pandas"

function first(wood, pumpkin){
    return "hi " + wood + pumpkin;
}

console.log(first("rubber ", "gloves"));

var num_1 = 10;
var num_2 = 2;

console.log(num_1 * num_2);

var myPet = {
       isFluffy: true,
       breed: "husky",
       age: 4,
};

console.log(myPet.breed);
















