$(document).ready(function(){

	var theSeconds = setInterval(function(){time() }, 1000);

	//background change every even/odd minute
	var evenOdd = setInterval(function(){everyMinute()}, 1000);

	//color changes random every hour
	var theHours = setInterval(function(){colorChange()}, 3600000);

	//background change every five minutes
	var fiveMinutes = setInterval(function(){backgroundChange()}, 300000);


	//displays clock
	function time(){
		var date = new Date();

		var hours = date.getHours();
		var minutes = date.getMinutes();
		var seconds = date.getSeconds();
		
		var timer = date.toLocaleTimeString();
		
		document.getElementById('clock').innerHTML = timer;
	}
	//background change every even/odd minute
	function everyMinute(){

		var date = new Date();
		var minutes = date.getMinutes();

	 	if(minutes % 2 === 0){
			document.body.style.background = 'white';
		} 
		else {
				document.body.style.background = 'black';
		}
	}
	//color changes random every hour
	function colorChange(){
		var colorArray = ['white','lightblue','cyan', 'yellow','pink','lightgreen','lightpurple'];
		var colorChoose = Math.floor(Math.random()*colorArray.length);

		document.getElementById('clock').style.color = colorArray[colorChoose];
		console.log('hi');
	}
	//background change every five minutes
	function backgroundChange(){
		var color = Math.floor(Math.random()*16777215).toString(16);

		document.body.style.background = '#'+color;
	}	
	
});