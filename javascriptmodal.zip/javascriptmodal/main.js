// modal
var modal = document.getElementById('myModal');

// open modal
var btn = document.getElementById("myBtn");

// close modal
var span = document.getElementsByClassName("close")[0];

// open modal
btn.onclick = function() {
    modal.style.display = "block";
}

// close modal
span.onclick = function() {
    modal.style.display = "none";
}

// close when clicked outside modal
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}