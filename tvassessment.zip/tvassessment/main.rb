require 'sinatra'
#load the mandrill gem
require "mandrill"
#load the sinatra gem
require "sinatra"

class Television
  attr_accessor :channel
  def initialize(channel = 'off' 'on')
    @channel = channel
  end
  def power
    if @power == :on
      @power = :off
    else
      @power = :on
  end
  def on?
    @power == :on
  end
end
  
class TvChannel
  def initialize(channel_number)
    @channel_number = channel_number
  end
  def change_channel (channel)
    @channel = channel
  end
  def program (channel)
    broadcast = channels[channel]
  end
  def now_playing (channel)
    playing = program(channel)
  end
end 

class TvVolume
  def initialize(volume_level)
    @volume_level = volume_level
    if @volume_level  == :up
      @volume_level  = :down
    else
      @volume_level  = :up
    end
  def change_volume (volume)
    @volume = volume
  end
  def sound
    if @sound == :mute
      @sound = :unmute
    else
      @sound = :mute
  end
  def current_volume (tvvolume)
    volume_level = current_volume(tvvolume)
  end
end

TV = Television.new() 

TvChannel.channel = now_playing
TvVolume.volume_level = tvvolume

puts TvChannel.channel
puts TvVolume.volume

# TV must be class and consequently you must create an instance of that class (object)
# Must be able to turn TV on and off
# Must be able to turn the volume up or volume down
# Must be able to mute and unmute volume (similar to TV on/off)
# Must be able to switch channels by going up in number or down (similar to volume)
 
# Change a channel by passing in the channel number
# Display the current channel number
# The channel cannot be greater than 100 or less than 1
# The volume cannot be greater than 32 or less than 1
# Display the current volume