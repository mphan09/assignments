require 'sinatra'
require 'sinatra/activerecord'
require "pry"

configure(:development){set :database, "sqlite3:my_sintara_db.sqlite3"}

require './models'



















